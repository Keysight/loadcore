import unittest

import os
import time

import requests
from requests.exceptions import ConnectionError
import logging
from pprint import pformat
import sys
import json
import datetime, shutil


import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logFileName = 'rest-tests-output.log'  # log file


class _TestCaseBase(unittest.TestCase):

    @staticmethod
    def setUpProp(obj):
        if obj.setupFailed:
            obj.fail('Test case setup failed')
            return
        obj.logger.info('Setting up test "%s"...' % obj._testMethodName)
        if not obj.singleInstance:
            obj.assertTrue(obj.lizard.start())
        if obj.lizard:
            obj.lizard.setTestcase(obj)

    @staticmethod
    def tearDownProp(obj):
        obj.logger.info('Tearing down test "%s"...' % obj._testMethodName)
        if obj.lizard:
            obj.lizard.setTestcase(None)
        if not obj.singleInstance:
            obj.lizard.stop()
            obj.logger.info('Test complete')

    def setUp(self):
        _TestCaseBase.setUpProp(self)

    def tearDown(self):
        _TestCaseBase.tearDownProp(self)

    extra_msg = None

    def assertEquals(self, left, right):
        if self.extra_msg != None:
            unittest.TestCase.assertEquals(self, left, right,
                                           "%s != %s (%s) " % (str(left), str(right), self.extra_msg))
        else:
            unittest.TestCase.assertEquals(self, left, right)


class TestCaseRemote(_TestCaseBase):
    @staticmethod
    def setUpClassProp(obj):
        obj.logger = None
        obj.logLevel = logging.DEBUG  # .INFO
        obj.lizard = None
        obj.singleInstance = True
        obj.setupFailed = False

        # Create a custom logger
        obj.logger = logging.getLogger(logFileName)
        logging.basicConfig(filename=logFileName, format='%(asctime)s - %(levelname)s - %(message)s',
                            datefmt='%m/%d/%Y %I:%M:%S %p', level=obj.logLevel)
        # Make logger also output to STDOUT in some cases
        if obj.logLevel == logging.WARNING:
            handler = logging.StreamHandler(sys.stdout)
            handler.setLevel(logging.ERROR)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            obj.logger.addHandler(handler)

        obj.logger.info('Setting up remote test case "%s"...' % obj.__name__)

    @staticmethod
    def tearDownClassProp(obj):
        obj.logger.info('Tearing down remote test case "%s"...' % obj.__name__)
        obj.logger.info('Test case complete')

    @classmethod
    def setUpClass(cls):
        TestCaseRemote.setUpClassProp(cls)

    @classmethod
    def tearDownClass(cls):
        TestCaseRemote.tearDownClassProp(cls)

    def newMW(self, host, licenseServer, username, password, port=443, protocol='https'):
        return MW(self.logger, self, host, licenseServer, username, password, port, protocol)



class Requests(object):
    def get(self, url, params=None, headers=None, stream=False):
        return requests.get('%s%s' % (self.baseurl, url), params=params, headers=headers, verify=False,
                                       stream=stream)

    def getInfoFromURL(self, url, params=None, headers=None):
        return requests.get('%s' % url, params=params, headers=headers, verify=False)

    def put(self, url, data, headers=None):
        return requests.put('%s%s' % (self.baseurl, url), data=(None if data is None else json.dumps(data)),
                                       headers=headers, verify=False)

    def putText(self, url, data, headers=None):
        return requests.put('%s%s' % (self.baseurl, url), data=data, headers=headers, verify=False)

    def post(self, url, data=None, headers=None):
        return requests.post('%s%s' % (self.baseurl, url), data=(None if data is None else json.dumps(data)),
                                        headers=headers, verify=False)

    def patch(self, url, data, headers=None):
        return requests.patch('%s%s' % (self.baseurl, url),
                                         data=(None if data is None else json.dumps(data)), headers=headers,
                                         verify=False)

    def delete(self, url, headers=None):
        return requests.delete('%s%s' % (self.baseurl, url), headers=headers, verify=False)

    def post_archive(self, url, data=None, headers=None):
        headers["Content-Type"] = "application/zip"
        return requests.post('%s%s' % (self.baseurl, url), data=(None if data is None else data),
                                        headers=headers, verify=False)

    def new_post(self, url, data=None, headers=None):
        # headers["Content-Type"] = "application/json"
        return requests.post('%s%s' % (self.baseurl, url), data=data,
                                        headers=headers, verify=False)

class MW(Requests):
    def __init__(self, logger, testcase=None, host='localhost', licenseServer='', username='admin', password='admin', port=443, protocol='https'):
        self.testcase = testcase
        self.logger = logger
        self.host = host
        self.port = port
        self.protocol = protocol
        self.process = None
        self.baseurl = '%s://%s:%d' % (self.protocol, self.host, self.port)
        self.username = username
        self.password = password
        self.auth_token = self.getToken()
        self.headers = {'authorization': self.auth_token}
        self.licenseServer = licenseServer
        self.setLicenseServer()


    def getToken(self):
        print('Getting the auth_token...')

        try:
            apiPath = '/auth/realms/keysight/protocol/openid-connect/token'
            self.headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            payload = { "grant_type" : "password", "username" : self.username, "password": self.password, "client_id": "clt-wap" }
            # use requests.post because payload is not json format as it is used in self.post()
            response = requests.post(self.baseurl + apiPath, data=payload, headers=self.headers, verify=False)
            print('auth_token: {}'.format(response.json()['access_token']))
        except Exception as e:
            print(e)
            return ""

        return response.json()["access_token"]

    def setLicenseServer(self):
        response = self.get('/api/v2/globalsettings', headers=self.headers)

        if response.json()["licenseServer"] == self.licenseServer:
            return 0

        # use KCOS as licenseType for embedded license server
        # use ExternalKCOS as licenseType for external license server
        payload = {"licenseServer": self.licenseServer, "licenseType": "ExternalKCOS"}
        response = self.put('/api/v2/globalsettings', payload, headers=self.headers)


    def newSession(self, configName=None, configID=None, configJson=None, configArchive=None, statusCode=201, sessionType='fullCore'):
        """
        :param configName:
        :param configID: specify a configID to create a new config and load the config with configID
        :param config: config in json format that will be uploaded and attached to the new session
        :return: new session ID
        """

        if sessionType == "fullCore":
            configType = "wireless-fullcore-config"

        if (configName == None and configJson == None and configID == None and configArchive == None):
            config = {"ConfigUrl": configType}
        elif configID != None:
            config = {"ConfigUrl": configID}
        elif (configName != None):
            # in this case create a new config by loading a specified config name
            config = self.selectConfig(configName)
            uploadedConfig = self.uploadConfig(config=config)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        elif (configJson != None):
            uploadedConfig = self.uploadConfig(config=configJson)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        elif configArchive != None:
            uploadedConfig = self.uploadConfig(configArchive=configArchive)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        else:
            self.logger.error("NewSession: Unhandled case")

        response = self.post('/api/v2/sessions', config, headers=self.headers)

        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode == 201:
            self.logger.debug(pformat(response.json()))
            return response.json()[0]['id']
        else:
            return response.json()

    def deleteSession(self, sessionID, statusCode=204):
        response = self.delete('/api/v2/sessions/{0}'.format(sessionID), headers=self.headers)
        # print response
        self.testcase.assertEquals(response.status_code, statusCode)
        if '200' in str(response.status_code):
            self.testcase.assertTrue(True if sessionID not in self.getAllSessions() else False)
            return response
        elif '204' in str(response.status_code):
            self.testcase.assertTrue(True if sessionID not in self.getAllSessions() else False)
            return response
        else:
            self.logger.debug(pformat(response))
            return response.status_code

    def getAllSessions(self):
        response = self.get('/api/v2/sessions', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        sessions = []
        for item in response.json():
            sessions.append(item['id'])

        return sessions

    def getSessionInfo(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def getSessionStatus(self, sessionID):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return response.json()['status']

    def isSessionStarted(self, sessionID):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return True if response.json()['status'] == 'Started' else False

    def pickExistingSession(self, wildcard):
        try:
            self.assertGreater(self.newSessionID, 0)
            return self.newSessionID
        except:
            allSessions = self.getAllSessions()
            for session in allSessions:
                if wildcard in session:
                    return session

    def getAllAgents(self):
        """
        :return: a list of agents
        """
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return response.json()

    def getAgentInfo(self, agentID):
        response = self.get('/api/v2/agents/{0}'.format(agentID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        
        return response.json()

    def getAgentIP(self, agentID):
        response = self.getAgentInfo(agentID)

        return response['IP']


    def getSessionConfig(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}/config?include=all'.format(sessionID), headers=self.headers)
        #self.logger.debug(pformat(response.json()))
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def selectConfig(self, configName):
        configFileName = 'configs/{0}.json'.format(configName)
        assert os.path.isfile(configFileName)

        file = open(configFileName)
        config = file.read()
        file.close()

        configJson = json.loads(config)
        #self.logger.debug(pformat(configJson))
        return configJson

    def setSessionConfig(self, sessionID, config, statusCode=200):
        self.headers.update({'Content-Type': 'application/json',
                             'Accept': '*/*',
                             'Cache-Control': 'no-cache',
                             'Host': '{0}'.format(self.host),
                             'Accept-Encoding': 'gzip, deflate',
                             'Referer': 'http://{0}/api/v2/sessions'.format(self.host),
                             'Postman-Token': '009256e4-5703-4564-8526-adfe3567fecd',
                             'User-Agent': 'PostmanRuntime/7.16.3',
                             'Connection': 'keep-alive'})
        if 'configData' in config:
            config = config['configData']['Config']


        response = self.put('/api/v2/sessions/{0}/config/config'.format(sessionID), data=config,
                            headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.reason))
        self.testcase.assertEquals(response.status_code, statusCode)
        try:
            return response.json()
        except:
            return response

    def startTest(self, sessionID, result='SUCCESS', wait=40, statusCode=202):
        response = self.post('/api/v2/sessions/{0}/test-run/operations/start'.format(sessionID), headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.json()))

        self.testcase.assertEquals(response.status_code, statusCode)
        waitTime = wait

        rest_url = '/api/v2/sessions/{0}/test-run/operations/start/{1}'.format(sessionID, response.json()['id'])

        while wait > 0:      
            try:
                state = self.get(rest_url, headers=self.headers)
                # self.logger.debug(pformat(state))
                # self.logger.debug(pformat(state.content))

                if state.json()['state'] == result:
                    return state.json()

                if state.json()['state'] == 'ERROR':  # break when start goes to ERROR state
                    break

                wait -= 1
                time.sleep(2)
                self.logger.debug(pformat(state.json()))

            except:
                return response.json()

        else:
            self.testcase.assertTrue(False, msg='Test failed to start in {} sec'.format(waitTime))
        
        # if state is ERROR, stop the test and print the error message.
        self.testcase.assertTrue(False, msg='State: {} - Error MSG: {}'.format(state.json()['state'], state.json()['message']))  

    def stopTest(self, sessionID, result='SUCCESS', wait=40, statusCode=202):
        response = self.post('/api/v2/sessions/{0}/test-run/operations/stop'.format(sessionID), headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.status_code))

        self.testcase.assertEquals(response.status_code, statusCode)

        rest_url = '/api/v2/sessions/{0}/test-run/operations/stop/{1}'.format(sessionID, response.json()['id'])

        while wait > 0:
            try:
                state = self.get(rest_url, headers=self.headers)
                # self.logger.debug(pformat(state))
                # self.logger.debug(pformat(state.content))

                if state.json()['state'] == result:
                    return state.json()

                if state.json()['state'] == 'ERROR':  # break when start goes to ERROR state
                    break

                wait -= 1
                time.sleep(2)
                self.logger.debug(pformat(state.json()))

            except:
                return response.json()

        else:
            self.testcase.assertTrue(False, msg='Test failed to stop')

        # if state is ERROR, stop the test and print the error message.
        self.testcase.assertTrue(False, msg='State: {} - Error MSG: {}'.format(state.json()['state'], state.json()['message']))


    def uploadConfig(self, config=None, configArchive=None, statusCode=201):
        """
        :param config: in json format
        :return:
        """
        if config != None:
            response = self.post('/api/v2/configs', data=config, headers=self.headers)
            # self.logger.debug(pformat(response.content))
            self.logger.debug(pformat(response.reason))
            self.testcase.assertEquals(response.status_code, statusCode)
            return response.json()
        if configArchive != None:
            with open("configs/" + configArchive, 'rb') as f:
                response = self.post_archive('/api/v2/configs',data=f, headers=self.headers)
                # self.logger.debug(pformat(response.content))
                self.logger.debug(pformat(response.reason))
                self.testcase.assertEquals(response.status_code, statusCode)
                return response.json()

    def getUploadedConfig(self, configID, statusCode=200):
        response = self.get('/api/v2/configs/{0}'.format(configID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def checkSessionState(self, sessionID, status, waitTime=300):
        elapsedTime = 0
        testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)  
        while elapsedTime < waitTime and testResponse.json()['status'] != status:
            try:
                testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
            except ConnectionError as e:
                break
            time.sleep(5)
            elapsedTime += 5
        return True if testResponse.json()['status'] == status else False    


    def getTestId(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()['testId']


    def getAllStats(self, testId, statName, statusCode=200):
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testId, statName), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        col = {}
        statList = []

        if response.json()['columns'][0] == "timestamp":
            try:
                for i in range(len(response.json()['columns']) - 1):
                    n = response.json()['columns'][i+1]
                    for j in range(len(response.json()['snapshots'])):
                        statList.append(float(response.json()['snapshots'][j]['values'][0][i+1]))
                    col[n] = statList
                    statList = []

                return col   # returns a dictionary. The keys are the statistics. The value for each key is a list of values with the polling interval 2 seconds.
            except:
                print("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
                pass
        
        else:
            try:
                for i in range(len(response.json()['columns'])-1):      # this is used for SBI stats.
                    n = response.json()['columns'][i+1]
                    for j in range(len(response.json()['snapshots'][0]['values'])):
                        statList.append(float(response.json()['snapshots'][0]['values'][j][i+1]))
                    col[n] = sum(statList)
                    statList = []
                return col 
            except:
                print("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
                pass

    def getMaxStat(self, stat):
        return max(stat)

    def getAvgNonZeroStat(self, stat):  
        statList = []
        for i in stat:
            if i != 0:
                statList.append(i)
        if len(statList) == 0:
            return 0                                        # if all values are zero, return 0 - For Failed/Timeout stats
        else:
            return round(sum(statList) / len(statList), 2)    # Returns AVG on non-zero values

    def getTestDuration(self, sessionID, multiplier=2):     # return total test duration x multiplier (when test takes longer because of retries)
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        total_duration = response.json()['testDuration'] * multiplier

        return total_duration

    def getAgentsInfo(self):
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        agents=response.json()
        agents_list = []
        for agent in agents:
            interface_list = []
            for interface in agent['Interfaces']:
                interface_list.append({'Name': interface['Name'], 'Mac': interface['Mac']})
            interface_list.sort(key=lambda x: x['Name'])
            agents_list.append({'id':agent['id'], 'IP':agent['IP'], 'Interfaces': interface_list})  # interfaces are stored in a list.
        return agents_list

    def getAgentDetails(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                return agent

    def RemapAgents(self, configToModify, agentsDict, sbaTesterTopology=False):
        import copy
        newConfig = copy.deepcopy(configToModify)
        topology = 'Config' if sbaTesterTopology is False else 'SBAConfig'

        for node in agentsDict:
            if newConfig['configData'][topology]['nodes'][node]['settings']['enable'] == True:
                path = newConfig['configData'][topology]['nodes'][node]['settings']['mappedAgents'][0]
                path['agentId'] = agentsDict[node][0]
                for i in range(len(path['interfaceMappings'])):
                    if path['interfaceMappings'][i]['agentInterface'] != 'none':
                        path['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                        path['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
        return newConfig

    def getStartEndTestTimestamp(self, sessionID):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)

        return response.json()['testStarted']*1000, response.json()['testStopped']*1000

    
    def createHTMLreport(self, sessionID, listOfStatistics, reportName, startTime, endTime):
        html = self.getHTML(sessionID, listOfStatistics, reportName, startTime, endTime)
        foldername = 'LoadCore_{}_{}/'.format(reportName, startTime.strftime('%Y%m%d_%H%M%S'))
        os.makedirs(os.path.dirname(foldername), exist_ok=True)
        filename = foldername + 'LoadCore_{}_{}'.format(reportName, startTime.strftime('%Y%m%d_%H%M%S'))

        with open('{}.html'.format(filename), 'w') as f:
            f.write(html)

        shutil.copy("keysightlogo.png", foldername)
        shutil.copy("loadcorelogo.PNG", foldername)


    def getHTML(self, sessionID, statsList, reportName, startTime, endTime):
        testId = self.getTestId(sessionID)
        t1, t2 = self.getStartEndTestTimestamp(sessionID)
        data = {}
        l = []
        start = startTime.strftime('%Y-%m-%d %H:%M:%S')
        end = endTime.strftime('%Y-%m-%d %H:%M:%S')
        
        html = """<html><head>
                <style>
                .collapsible {
                background-color: #282828;
                color: white;
                cursor: pointer;
                padding: 18px;
                width: 100%;
                border: none;
                text-align: left;
                outline: none;
                font-size: 15px;
                }

                .active, .collapsible:hover {
                background-color: #808080;
                }
                .collapsible:after {
                content: '\\002B';
                color: white;
                font-weight: bold;
                float: right;
                margin-left: 5px;
                }

                .active:after {
                content: "\\2212";
                }


                .content {
                display: inline-block;
                padding: 0 18px;
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.2s ease-out;
                overflow: hidden;
                background-color: white;
                }

                .column {
				  float: left;
				  padding: 1px;
				}

				.row:after {
				  content: "";
				  display: table;
				  clear: both;
				}
				.left {
				  width: 20%;
				}
				.middle {
				  width: 15%;
                  color: #282828;
				}
				.right {
				  float: right;
				  width: 20%;
				}
                </style>
                </head>
                <body>
                <div class="row">
					<div class="column left">
						<img src="loadcorelogo.PNG", 
						 height = 48 width = 158/>
					</div>
                """
        session = self.getSessionInfo(sessionID)
        html += '<div class="column middle"><center><b>{}</b></center></div>'.format(session['owner'])
        html += '<div class="column middle"><center><b>{}</b></center></div>'.format(reportName)
        html += '<div class="column middle"><center><b>{}</b></center></div>'.format(start)
        html += '<div class="column middle"><center><b>{}</b></center></div>'.format(end)

        html += """<div class="column right"><img src="keysightlogo.PNG", 
						height = 48 width = 158 style="float:right;margin-top: -25px;"/>
					</div>
				</div>
                """

        for stat in statsList:
            response = self.get('/api/v2/results/{}/stats/{}?from={}'.format(testId, stat, t1), headers=self.headers)
            try:
                if response.json()['columns'][0] == "timestamp":
                    for i in range(len(response.json()['columns'])):
                        n = response.json()['columns'][i]
                        for j in range(len(response.json()['snapshots'])):
                            l.append(response.json()['snapshots'][j]['values'][0][i])
                        data[n] = l
                        l = []
                    
                    html += '<button type="button" class="collapsible">{}</button><div class="content">'.format(stat)
                    html += '<table border="1"><tr><th>' + '</th><th>'.join(data.keys()) + '</th></tr>'

                    for row in zip(*data.values()):
                        html += '<tr><td>' + '</td><td>'.join(row) + '</td></tr>'

                    html += '</table></div>'
                    data.clear()

                else:
                    for i in range(len(response.json()['columns'])):
                        n = response.json()['columns'][i]
                        for j in range(len(response.json()['snapshots'][0]['values'])):
                            l.append(response.json()['snapshots'][0]['values'][j][i])
                        data[n] = l
                        l = []

                    html += '<button type="button" class="collapsible">{}</button><div class="content">'.format(stat)
                    html += '<table border="1"><tr><th>' + '</th><th>'.join(data.keys()) + '</th></tr>'

                    for row in zip(*data.values()):
                        html += '<tr><td>' + '</td><td>'.join(row) + '</td></tr>'

                    html += '</table></div>'
                    data.clear()

            except:
                print("Exception raised: No stats available for {} view.".format(stat))
                pass

        #print(data)

        html += """
                </body>
                <script>
                var coll = document.getElementsByClassName("collapsible");
                var i;

                for (i = 0; i < coll.length; i++) {
                coll[i].addEventListener("click", function() {
                    this.classList.toggle("active");
                    var content = this.nextElementSibling;
                    if (content.style.maxHeight){
                    content.style.maxHeight = null;
                    } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                    } 
                });
                }
                </script>
                </html>
                """

        return html

    
    def getPDFreport(self, sessionID, folder, startTime, wait=40, statusCode=202):
        testID = self.getTestId(sessionID)

        response = self.post('/api/v2/results/{0}/operations/generate-pdf'.format(testID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-pdf/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                pdfReport = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'Could not get the pdf report')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the pdf report. Try increasing the wait time.')


        foldername = 'LoadCore_{}_{}/'.format(folder, startTime.strftime('%Y%m%d_%H%M%S'))
        os.makedirs(os.path.dirname(foldername), exist_ok=True)

        filename = '{0}/{1}'.format(foldername, pdfReport.headers['Content-Disposition'].split("=")[1].strip('\"').replace(':','-'))

        with open(filename, 'wb') as f:
            f.write(pdfReport.content)


    def getCSVs(self, sessionID, folder, startTime, wait=40, statusCode=202):
        testID = self.getTestId(sessionID)

        response = self.post('/api/v2/results/{0}/operations/generate-csv'.format(testID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-csv/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                archive = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'Could not get the results archive')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the results archive. Try increasing the wait time.')

        foldername = 'LoadCore_{}_{}/'.format(folder, startTime.strftime('%Y%m%d_%H%M%S'))
        os.makedirs(os.path.dirname(foldername), exist_ok=True)

        filename = '{0}/{1}'.format(foldername, archive.headers['Content-Disposition'].split("=")[1]).replace('"','').replace(':','-')

        with open(filename, 'wb') as f:
            f.write(archive.content)

    def getCapturesLogs(self, sessionID, folder, startTime, wait=40, statusCode=202):
        testID = self.getTestId(sessionID)

        response = self.post('/api/v2/results/{0}/operations/export-results'.format(testID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-results/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                archive = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'Could not get the captures/logs archive')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the capture')

        foldername = 'LoadCore_{}_{}/'.format(folder, startTime.strftime('%Y%m%d_%H%M%S'))
        os.makedirs(os.path.dirname(foldername), exist_ok=True)
        
        filename = '{0}/{1}'.format(foldername, archive.headers['Content-Disposition'].split("=")[1]).replace('"','').replace(':','-')

        with open(filename, 'wb') as f:
            f.write(archive.content)

        return filename

    def getAgentInterfaces(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                return agent['Interfaces']

    def getTopologyFromSessionConfig(self, config):
        category = config['ConfigType']

        if category == 'Full Core':
            return 'Config'
        elif category == 'SBA':
            return 'sbaConfig'
        elif category == 'UPF Isolation':
            return 'upfIsolationConfig'
        elif category == 'iRAT':
            return 'IRATConfig'

    def getAgentNodeID(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                return agent['id']

    def getInterfaceMAC(self, agentsInfo, agentIP, interfaceName):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                for interface in agent['Interfaces']:
                    if interface['Name'] == interfaceName:
                        return interface['Mac']  

    def updateNetworkSettings(self, configToModify, networkSettings, topology):
        import copy
        newConfig = copy.deepcopy(configToModify)
        AgentsInfo = self.getAgentsInfo()

        # modify networkSettings structure
        agentsInfos = []

        for agent in networkSettings:
            d = {'agentId':agent, \
                'id': '', \
                'impairmentId': '-1'
                }
            temp = []
            for interface in networkSettings[agent]:
                 temp.append({'capture': False, 'interfaceName': interface, 'interfaceMac': self.getInterfaceMAC(AgentsInfo, self.getAgentIP(agent), interface), \
                            "networkStack": "linuxStack", "sriov": False})
            d['interfacesSettings'] = temp
            agentsInfos.append(d)

        # a config json file is different from a config extracted from session
        newConfig[topology]['networkSettings']['agentsInfos'] = agentsInfos
        # print(newConfig['configData'][path])

        return newConfig

    def assignAgents(self, sessionID, agentsDict):
        """
        four methods to assign agent to  5G nodes:
        1. agentsDict[node] = self.Agent1 
            it will use the agent's first test interface

        2. agentsDict[node] = [{'agent': self.Agent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
            it will assign 'agent' to the node as described in the dict

        3. agentsDict[node] = [(self.Agent1, 'ens192')]
            it will use the exact test interface (ens192)
        
        4. agentsDict[node] = [self.Agent1, self.Agent2]
           agentsDict[node] = [(self.Agent2, 'ens192'),(self.Agent1, 'ens160')]
            this is used to assign multiple agents on every node. It will use the first interface.
            Can be used also as tuple: assign first agent with a specific interface, assign second with specific interface.

        """
        def __create_Mappings(agentsInfo, agentIP, testInterface, networkSettings):
            topology = self.getTopologyFromSessionConfig(config)
            defaultDict = defaultFullcoreDict
            if topology == 'sbaConfig':
                defaultDict = defaultSBATesterDict
            AgentNodeID = self.getAgentNodeID(agentsInfo, agentIP)
            if AgentNodeID not in networkSettings:      # check if agent already exist. If not, create key.
                networkSettings[AgentNodeID] = []
            for interface in defaultDict[node]:                 # go through each node interface and create the dict
                agentInterface = testInterface
                agentInterfaceMac = self.getInterfaceMAC(agentsInfo, agentIP, testInterface)
                if interface == 'passthroughDevice' or (node == 'upf' and interface == 'n6'):    # check for passthrough on ran and n6 on upf
                    agentInterface = "none"
                    agentInterfaceMac = "none"
                interfaceMappings.append({
                                        'agentInterface': agentInterface, \
                                        'agentInterfaceMac': agentInterfaceMac, \
                                        'nodeInterface': interface
                                        })
                if agentInterface not in networkSettings[AgentNodeID] and agentInterface != 'none':
                    networkSettings[AgentNodeID].append(agentInterface)
            
            return AgentNodeID, interfaceMappings, networkSettings[AgentNodeID]

        # each 5G node with its interfaces. This can suffer changes between releases
        defaultFullcoreDict = { 
                        'amf': ['n2', 'namf', 'n26'], 'ausf': ['nausf'], 'dn': ['n6'], 'eir': ['n5geir'], \
                        'ims': ['n6','rx'], 'mediaforwarder': ['n6'], 'mme': [], 'nrf': ['nnrf'], 'nssf': ['nnssf'], 'pcf': ['npcf', 'rx'], \
                        'ran': ['n2', 'n3', 'passthroughDevice', 's1u', 'n26', 's6a', 's5c', 's5u', 's11','s1'], 
                        'sgw': [], 'smf': ['n4', 'nsmf', 's5c', 's11'], 'smsf': ['nsmsf'], 'udm': ['nudm', 's6a'], 'udr': ['nudr'], \
                        'upf': ['n3', 'n4', 'n6', 'n9'], 'sbaTester': ['namf','nsmf','npcf'], 'chf': ['nchf']
                        }

        defaultSBATesterDict = { 
                        'ausf': ['nausf'], 'nrf': ['nnrf'], 'nssf': ['nnssf'], 'pcf': ['npcf'], 'udm': ['nudm'], 'udr': ['nudr'], \
                        'sbaTester': ['namf','nsmf','npcf'], 'chf': ['nchf']
                        }


        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)

        path = config[topology]['nodes']

        agentsInfo = self.getAgentsInfo()
        networkSettings = {}
        payload = {}

        for node in agentsDict:         # go through each node
            mappedAgents = []
            if type(agentsDict[node]) is not list:                  # if not list, convert to list. This helps multi agent support
                agentsDict[node] = agentsDict[node].split("-")
            for agent in agentsDict[node]:                          # go through each agent.
                interfaceMappings = []
                mappedDict = {}
                if type(agent) is dict:       #[{'agent': self.lizardAgent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
                    agentIP = agent['agent']
                    AgentNodeID = self.getAgentNodeID(agentsInfo, agentIP)
                    if AgentNodeID not in networkSettings:      # check if agent already exist. If not, create key.
                        networkSettings[AgentNodeID] = []
                    del agent['agent']
                    nodeInterfaces = agent
                    
                    for interface in nodeInterfaces:
                        if nodeInterfaces[interface] == 'none':
                            agentInterfaceMac = 'none'
                        else:
                            agentInterfaceMac = self.getInterfaceMAC(agentsInfo, agentIP, nodeInterfaces[interface])
                        interfaceMappings.append({
                                        'agentInterface': nodeInterfaces[interface], \
                                        'agentInterfaceMac': agentInterfaceMac, \
                                        'nodeInterface': interface
                                        })
                        if nodeInterfaces[interface] not in networkSettings[AgentNodeID] and nodeInterfaces[interface] != 'none':
                            networkSettings[AgentNodeID].append(nodeInterfaces[interface])
                        # print(interfaceMappings)
                elif type(agent) is tuple:
                    AgentNodeID, interfaceMappings, networkSettings[AgentNodeID] = __create_Mappings(agentsInfo, agent[0], agent[1], networkSettings)

                else:
                    AgentNodeID, interfaceMappings, networkSettings[AgentNodeID] = __create_Mappings(agentsInfo, agent, \
                                                                                    self.getAgentInterfaces(agentsInfo, agent)[0]['Name'], networkSettings)

                # create list of assigned agents.
                mappedDict = {'agentId': AgentNodeID, 'id': "", "interfaceMappings": interfaceMappings}
                mappedAgents.append(mappedDict)


            path[node]['settings']['mappedAgents'] = mappedAgents

            payload[node] = path[node]      # create payload
        

        response = self.patch('/api/v2/sessions/{}/config/{}/nodes'.format(sessionID,topology.lower() if topology == 'Config' else topology), data=payload, headers=self.headers)
        self.testcase.assertEqual(response.status_code, 204)


        # populate networkSettings with current agents
        updatedNetworkSettings = self.updateNetworkSettings(config, networkSettings, topology)[topology]['networkSettings']

        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID,topology.lower() if topology == 'Config' else topology), data=updatedNetworkSettings, headers=self.headers)
        self.testcase.assertEqual(response.status_code, 204)
        
    def changeNetworkSettings(self, sessionID, agentIP, interface, **kwargs):
        """
        Used to manipulate capture, networkStack and sriov. These options are available per interface
        
        'networkStack': 'linuxStack' -> for linuxstack

        'networkStack': 'ixStack' -> ixStack with Raw Sockets

        'networkStack': 'dpdk' -> ixStack with DPDK

        'capture': True / False

        'sriov': True / False

        """      
        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)
        AgentsInfo = self.getAgentsInfo()
        networkSettings = config[topology]['networkSettings']
        agentId = self.getAgentNodeID(AgentsInfo, agentIP)

        for agent in networkSettings['agentsInfos']:
            if agent['agentId'] == agentId:
                for interfaceName in agent['interfacesSettings']:
                    if interfaceName['interfaceName'] == interface:
                        interfaceName['interfaceMac'] = self.getInterfaceMAC(AgentsInfo, agentIP, interface)
                        for key, value in kwargs.items():
                            interfaceName[key] = value
        
        if topology == 'Config':
            topology = topology.lower()
        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID, topology), data=networkSettings, headers=self.headers)
        self.testcase.assertEqual(response.status_code, 204)


    # add a new range on a specified node
    def add_range(self, sessionID, node, payload={},topology="config",rangeType="ranges"):
        # response = self.new_post('/api/v2/sessions/{0}/config/{1}/nodes/{2}/{3}'.format(sessionID, topology, node, rangeType), data=payload, headers=self.headers)
        response = self.post('/api/v2/sessions/{0}/config/{1}/nodes/{2}/{3}'.format(sessionID, topology, node, rangeType), data=payload, headers=self.headers)
        # print(response.text)
        self.testcase.assertEquals(response.status_code, 201)

        return response.json()

    # patch any option on a specified node
    def patch_option(self, sessionID, node, payload={},topology="config",api_endpoint="/ranges/1"):
        response = self.patch('/api/v2/sessions/{0}/config/{1}/nodes/{2}{3}'.format(sessionID, topology, node, api_endpoint), data=payload, headers=self.headers)
        self.testcase.assertEquals(response.status_code, 204)